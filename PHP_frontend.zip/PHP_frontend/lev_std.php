<!DOCTYPE html>
<html>
<head>
	<title>Students Data | Admin</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<style type="text/css">
		*{
	margin: 0px;
	padding: 0px;

}


.container{
	width: 100%;
	height: 100vh;
}

.section{
	width: 100%;
	
}

.section-1{
	float: left;
	width: 30%;
	height: 100vh;
	background-color: red;
	text-align: center;
}

.section-1 button{
	margin-top: 75px;
	text-align: center;
	width: 90%;
	padding: 5px 10px;
	border-radius: 5px;
	cursor: pointer;
	
}

.section-2{
	float: right;
	width: 70%;
	height: 100%;
	background-color: black;
	position: relative;
	
}
.section-2 .table-section{
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
	background-color: red;
	width: 90%;
	height: 90%;
}

.table-section h1{
	text-align: center;

}

table {

  	font-family: arial, sans-serif;
  	border-collapse: collapse;
  	width: 90%;
  	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

	</style>
</head>
<body>

	<div class="container">
		
		<div class="section">
			<div class="section-1">
				<a href="mn_rm.php">
					<button>Manage Room</button>
				</a>

				<a href="new_std.php">
					<button>New Student</button>
				</a>

				<a href="up_std.php">
					<button>Update Student Data</button>
				</a>

				<a href="fees.php">
					<button>Fees</button>
				</a>

				<a href="all_std.php">
					<button>All Student Living</button>
				</a>

				<a href="lev_std.php">
					<button>Leaved Students</button>
				</a>

				
				

			</div>
			
		</div>
		<div class="section-2">

			<div class="table-section">
				
				<h1>Students Data</h1>

				<table>
				  <tr>
				    <th>ID</th>
				    <th>Student Name</th>
				    <th>Password</th>
				    <th>Email ID</th>
				    <th>Contact Number</th>
				    <th>Room Number</th>
				    <th>Living status</th>
				  </tr>
				  <?php

					include("connection.php");
					$query = "select * from users where id = 4";
					$data = mysqli_query($con, $query);
					$total = mysqli_num_rows($data);

					if($total != 0) {
						
						while($result = mysqli_fetch_assoc($data))
						{
							echo "<tr>
							<td>".$result['id']."</td>
							<td>".$result['user_name']."</td>
							<td>".$result['password']."</td>
							<td>".$result['email']."</td>
							<td>".$result['mobile']."</td>
							</tr>"
							;
						}
					}
					else
					{
						echo "Data Not Found";
					}

				?>
				  
				</table>
			</div>
				
		</div>
		

	</div>


</body>
</html>
