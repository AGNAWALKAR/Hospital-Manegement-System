
<!DOCTYPE html>
<html>
<head>
	<title>Home | Admin</title>
	<link rel="stylesheet" type="text/css" href="std_home.css">
</head>
<body>

	<div class="body">
			<div class="btn-space">

				<div class="btn">
					<a href="mn_rm.php">
						<button class="lol">Manage Room</button>
					</a>
				
				</div>

				<div class="btn">
					<a href="mn_rm.php">
						<button class="lol">New Student</button>
					</a>
				</div>

			</div>	
			<div class="heading">
				
					<h1>Rajgad Hostel</h1>
					<h2>SIMCA, Narhe</h2>

			</div>
	</div>

</body>
</html>
