<?php



?>

<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
	<link rel="stylesheet" type="text/css" href="login.css">
</head>
<body>

	<div class="middle-part">
		<h1>Hostel Management System</h1>
		<h2>Hostel | Paying guest | Rent Room</h2>
		<a href="login.php">
			
			<button class="btn-1">Admin login</button>

		</a>
		<a href="std_lg/login.php">
			
			<button class="btn-2">Student login</button>
			
		</a>
		

    </div>
	

</body>
</html>