<?php 
session_start();

	include("connection.php");
	include("functions.php");


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$room_no = $_POST['room_no1'];
		$status = $_POST['status1'];

		if(!empty($room_no) && !empty($status))
		{

			//save to database
			
			$query = "update rooms set room_no = '$room_no', status = '$status' where room_no = $room_no";

			mysqli_query($con, $query);
			header("Location: mn_rm.php");

			die;
		}else
		{
			echo "Data is not pushed";
		}
	}
?>